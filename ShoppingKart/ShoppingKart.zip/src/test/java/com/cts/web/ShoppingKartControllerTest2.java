package com.cts.web;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ShoppingKartControllerTest2 {

	@Test
	void testShoppingPage() {
		fail("Not yet implemented");
	}

	@Test
	void testShoppingProcess() {
		fail("Not yet implemented");
	}

}
