package com.cts.exception;

public class ProductEmptyException extends Exception {

	public ProductEmptyException(String s) {
	super(s);
	}
	
}
