package com.cts.exception;

public class ProductAlreadyPresentException extends Exception {

	public ProductAlreadyPresentException(String s) {
		super(s);
	}
}
