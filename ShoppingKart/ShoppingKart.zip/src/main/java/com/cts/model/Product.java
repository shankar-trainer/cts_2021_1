package com.cts.model;

public class Product {
	private Integer prdId;
	private String prdName;
	private Float prdCost;
	private String prdLocation;

	public Integer getPrdId() {
		return prdId;
	}

	public void setPrdId(Integer prdId) {
		this.prdId = prdId;
	}

	public String getPrdName() {
		return prdName;
	}

	public void setPrdName(String prdName) {
		this.prdName = prdName;
	}

	public Float getPrdCost() {
		return prdCost;
	}

	public void setPrdCost(Float prdCost) {
		this.prdCost = prdCost;
	}

	public String getPrdLocation() {
		return prdLocation;
	}

	public void setPrdLocation(String prdLocation) {
		this.prdLocation = prdLocation;
	}

}
