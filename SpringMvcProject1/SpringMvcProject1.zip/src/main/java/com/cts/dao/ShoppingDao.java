package com.cts.dao;

public class ShoppingDao {

}
