package com.cts.model;

public class Hello {

	private String ActName;

	public String getActName() {
		return ActName;
	}

	public void setActName(String ActName) {
		ActName = this.ActName;
	}
	
}
