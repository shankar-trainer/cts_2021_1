package edu.abc;

import cts.com.core.Circle;

public class Test {

	public static void main(String[] args) {
		Circle circle=new Circle();
		circle.setRadius(5.5f);
		
		System.out.println(circle.circleArea());
	}
	
}
