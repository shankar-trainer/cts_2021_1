package cts.com.aop;

public class MyProgram1 {

	public void  display() {
		System.out.println("hello world");
	}
	
}
