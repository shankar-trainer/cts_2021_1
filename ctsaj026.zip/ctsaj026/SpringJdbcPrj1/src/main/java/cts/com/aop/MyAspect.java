package cts.com.aop;

public class MyAspect {

	private void method1() {
		System.out.println("called before  method");
	}
	
	private void method2() {
		System.out.println("called after  method");
	}
	
}
