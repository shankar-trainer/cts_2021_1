package cts.com.app;

public interface StockService {

	public double getPrice(Stock stock);
	
}
