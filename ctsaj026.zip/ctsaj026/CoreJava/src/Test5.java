
public class Test5 {

	public static void main(String[] args) {
		
		int a=10;
		
		a=a+1;
		System.out.println(a);
		a+=1;
		System.out.println(a);
		a++;
		System.out.println(a);

		
		a=a+3;
		a+=3;
		
		
		
		
	}
}
