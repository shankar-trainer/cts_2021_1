
public class WarppeerDemo3 {

	public static void main(String[] args) {

		
	String p1=	Integer.toString(1000);
	String p2=	Integer.toOctalString(1000);
	String p3=	Integer.toString(1000,10);
	String p4=	Integer.toString(1000,16);
	String p5=	Integer.toString(1000,8);
	String p6=	Integer.toString(1000,2);
		
	System.out.println(p1);
	System.out.println(p2);
	System.out.println(p3);
	System.out.println(p4);
	System.out.println(p5);
	System.out.println(p6);
		
	}
}
