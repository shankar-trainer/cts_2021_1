
public final  class Formula {

	float interestCalFormula(int amt, int time, float rate) {
		return amt * time * rate / 100;
	}

	float speed(int d1, int d2) {
		return (d1 + d2) / 2;
	}

}

class myFormula 
//extends Formula 
{
	/*
	 * @Override float speed(int d1, int d2) { return (d1 + d2) / 3; }
	 * 
	 * @Override float interestCalFormula(int amt, int time, float rate) { return
	 * amt * time * rate / 400;
	 * 
	 * }
	 */
}