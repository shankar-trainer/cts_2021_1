
public class Leader {

	private int leaderId;
	private String leaderName;
	private int leaderAge;
	private Speech speech;
	   // Leader has speech  -- has a relationship
	
	public int getLeaderId() {
		return leaderId;
	}
	public void setLeaderId(int leaderId) {
		this.leaderId = leaderId;
	}
	public String getLeaderName() {
		return leaderName;
	}
	public void setLeaderName(String leaderName) {
		this.leaderName = leaderName;
	}
	public int getLeaderAge() {
		return leaderAge;
	}
	public void setLeaderAge(int leaderAge) {
		this.leaderAge = leaderAge;
	}
	public Speech getSpeech() {
		return speech;
	}
	public void setSpeech(Speech speech) {
		this.speech = speech;
	}
	
	
	
	
	
	
}
