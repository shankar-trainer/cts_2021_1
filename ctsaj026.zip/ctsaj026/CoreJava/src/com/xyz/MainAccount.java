package com.xyz;

import com.cts.Account;

public class MainAccount {

	public static void main(String[] args) {
		Account act=new Account();
		act.accountId=9989;
		act.accountName="k kumar";
		
		System.out.println(act.accountId);
		System.out.println(act.accountName);
		
	}
}
