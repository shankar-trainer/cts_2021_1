package com.cts.collection;

public interface StrInterface {

}