package com.cts.collection;

public class ReverseSuper {

	public ReverseSuper() {
		super();
	}

}