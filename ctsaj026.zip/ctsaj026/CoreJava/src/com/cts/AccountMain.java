package com.cts;

public class AccountMain {

	public static void main(String[] args) {
		Account account=new Account();
		account.accountId=988998;
		account.accountName="saving account";
		System.out.println(account.accountId);
		System.out.println(account.accountName);
	}
}
