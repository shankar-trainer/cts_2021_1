package com.cts.datetime;

import java.util.Date;

public class Java7Date {

	
	public static void main(String[] args) {
		Date date=new Date();
		System.out.println(date);
		
		date=new Date(67677678887L);
		
		System.out.println(date);
		
	}
}
