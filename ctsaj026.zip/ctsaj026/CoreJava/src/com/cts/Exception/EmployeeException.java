package com.cts.Exception;

public class EmployeeException extends Exception{
	 
	public EmployeeException(String s) {
	  super(s);
	 }

}
