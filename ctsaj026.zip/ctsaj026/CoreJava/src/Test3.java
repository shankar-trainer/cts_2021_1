
public class Test3 {

	public static void main(String[] args) {
		
		
		System.out.println(10/2);
		System.out.println(10%2);
		
		System.out.println(10/3);//3
		System.out.println(10%3);//1 

		System.out.println(10/6);//1
		System.out.println(10%6);//4 
		
		
		
	}
}
