
public class WhileLoop {

	public static void main(String[] args) {
		
		int counter=1;
		
		while(counter<=20) {
			System.out.println(counter);
			counter++;
		}
	}
}
