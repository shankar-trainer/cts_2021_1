
public class Hello {

	public static void main(String[] args) {

		System.out.println("hello ");
		// single line comment 
		// sysout   ctrl+space
		System.out.print("welcome ");
		System.out.print("greeting ");
	
	}

}
