
public class AllData {

	public static void main(String[] args) {
		int x=65655665;
		
		int y=0b10101;
		int z=0x676abc;
		int a=676;
		
		System.out.println(x);
		System.out.println(y);
		System.out.println(z);
		
		//int 123;
		int _123;
		
		int $aaa;
		
		//int %aaa;
		//int &aaa;
		
				
	}
}
