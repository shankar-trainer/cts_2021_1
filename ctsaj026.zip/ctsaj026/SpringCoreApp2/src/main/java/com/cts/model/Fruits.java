package com.cts.model;

public class Fruits {

	private int fruitsId;
	private String  fruitsName;
	private String fruitsLocation;
	private float fruitsCost;
	
	public int getFruitsId() {
		return fruitsId;
	}
	public void setFruitsId(int fruitsId) {
		this.fruitsId = fruitsId;
	}
	public String getFruitsName() {
		return fruitsName;
	}
	public void setFruitsName(String fruitsName) {
		this.fruitsName = fruitsName;
	}
	public String getFruitsLocation() {
		return fruitsLocation;
	}
	public void setFruitsLocation(String fruitsLocation) {
		this.fruitsLocation = fruitsLocation;
	}
	public float getFruitsCost() {
		return fruitsCost;
	}
	public void setFruitsCost(float fruitsCost) {
		this.fruitsCost = fruitsCost;
	}

	
}
