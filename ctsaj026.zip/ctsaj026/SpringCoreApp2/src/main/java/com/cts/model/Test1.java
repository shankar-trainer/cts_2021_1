package com.cts.model;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Test1 {

	public static void main(String[] args) {
		Date date=new Date("12/10/2020");
	//	MM/dd/yyyy
		System.out.println(date);
	 
	}
}
