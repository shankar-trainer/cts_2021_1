
public class Ex4 {

	public static void main(String[] args) {
		int x=23;
		
		System.out.println(x/10);
		System.out.println(x%10);
		
	}
}
