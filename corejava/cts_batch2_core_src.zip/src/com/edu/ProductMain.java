package com.edu;

//import com.cts.*;

import com.cts.Product;;


public class ProductMain  extends Product {
	

	public static void main(String[] args) {
		Product product=new Product();
		product.pid=877887;
		product.name="java book";
		
		ProductMain main=new ProductMain();
		
		main.price=778.456f;
		
		
	}
}
