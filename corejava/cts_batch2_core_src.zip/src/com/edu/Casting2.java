package com.edu;

public class Casting2 {

	public static void main(String[] args) {
		
		
		Integer p=788;
		
		Float f=322.88f;
		
		//p=f;
		//f=p;
		
		Number n1=f;
		Number n2=p;
		
		
		
		
		
	}
}
