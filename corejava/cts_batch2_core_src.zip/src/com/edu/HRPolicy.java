package com.edu;

public final  class HRPolicy {

	void rule1() {
		
	}
	
	void rule2() {
		
	}
}

 class CompanyPolicy 
 //extends HRPolicy
 {
	public static void main(String[] args) {
		HRPolicy hrPolicy=new HRPolicy();
		//Math math=new Math();
	System.out.println(Math.E);
	System.out.println(Math.sin(Math.PI/2));
	} 
 }