package com.cts.collection;

import java.util.Arrays;

public class StringSorting {

	public static void main(String[] args) {
		
		String ITComapnies[]= {"CTS","IBM","Polaris","HCL","Wipro","CapG"};
	
		Arrays.sort(ITComapnies);
		
		System.out.println(Arrays.toString(ITComapnies));// ascending way
	
	}
}
