package com.cts.collection;

import java.util.stream.Stream;

public class Test11 {

	public static void main(String[] args) {
	
	}
}
