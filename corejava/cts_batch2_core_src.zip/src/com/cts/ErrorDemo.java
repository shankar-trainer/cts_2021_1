package com.cts;

public class ErrorDemo {

	static void disp() {
		disp();

	}

	public static void main(String[] args) {
		disp();
		Error e;
		
	}
}
