
public class Ex3 {

	java.lang.Integer s;
    java.lang.Object o;

	
	public static void main(String[] args) {
		float a=7676.67F;
		
		double d1=898899.677;
		
//System.out.println(1/0);
		
System.out.println(1.0/0);		
System.out.println(-1.0/0);		

		
		
	}
}
