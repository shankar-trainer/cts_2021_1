package corejava;

public class formtatEx1 {

	public static void main(String[] args) {
		float price=6676.76657f;
		System.out.println(price);
		System.out.printf("%20.2fprice",price);
		System.out.format("\n%20.2fprice",price);
		System.out.format("\n%-20.2fprice",price);
		
		
	}
}
