package corejava;

public class WrapperEx1 {

	public static void main(String[] args) {

		int x = 78878;

		// int p=767676766776;
		int p = 2147483647;

		long p1 = 2147483648l;// integer literal is by default int

		// int ---------------- Integer class

		System.out.println(Integer.MAX_VALUE);// 2147483647

		System.out.println(Integer.MIN_VALUE); // -2147483648

		byte b1 = 123;

		b1 = 127;

		short b2 = 128;
		
		

	}
}
