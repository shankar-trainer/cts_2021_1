package com.cts.error;

public class ProductUpdateException   extends Exception{

	public ProductUpdateException(String s) {
	 super(s);
	}
}
