package cts.com.app;

import java.util.Scanner;

public class UserInput {

	boolean input(String s) {
		if (s .equals( new String("mohan kumar")))
			return true;
		else
			return false;
	}
}
