package com.cts;

import com.cts.model.Student;

public class Stundet {

	int roll;
	String name;
	
	String country;
	float price;

	public int getRoll() {
		return roll;
	}


	public void setRoll(int roll) {
		this.roll = roll;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	
	
	public static void main(String[] args) {
	
		String country;
		
		String state;
		
		for (int i = 0; i < args.length; i++) {
			
		}
		
		Student st=new Student();
		
		
	}
}
