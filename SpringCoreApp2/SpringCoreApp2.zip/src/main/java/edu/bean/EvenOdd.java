package edu.bean;

public class EvenOdd {
	
	boolean testMethod(int p)
	{
		return p%2==0;
	}	
	
}
