package edu.bean;

public interface CalculatorService {

	public double addition(double a, double b);
	public double subtraction(double a, double b);
	public double division(double a, double b);
	
	public int divisionInt(int a, int b);
	
	public double multiplication(double a, double b);
	
	
	
}
