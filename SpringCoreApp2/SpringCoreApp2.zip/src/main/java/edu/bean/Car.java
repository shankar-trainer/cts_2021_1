package edu.bean;

public interface Car {

	 boolean needFuel();
	 double getEngineTemperature();
	 void driveTo(String destination);
	
}
