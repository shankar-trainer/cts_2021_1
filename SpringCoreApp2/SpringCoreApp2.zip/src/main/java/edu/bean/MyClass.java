package edu.bean;

public class MyClass {

	 public int getUniqueId(){
		 return 101;
	 }
}
