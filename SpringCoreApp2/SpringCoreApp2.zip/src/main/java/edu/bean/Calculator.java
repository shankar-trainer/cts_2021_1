package edu.bean;

public class Calculator {

	public float sum(float a, float b) {
		return a+b;
	}
	
	public float subtraction(int a, int b) {
		return a-b;
	}
}


