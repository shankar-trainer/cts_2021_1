package edu.bean;

public class Player {
	private String weapon;

	public Player(String weapon) {
		super();
		this.weapon = weapon;
	}

	public String getWeapon() {
		return weapon;
	}

}
