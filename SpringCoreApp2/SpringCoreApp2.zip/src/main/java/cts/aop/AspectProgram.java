package cts.aop;

public class AspectProgram {

	private void method1() {
		System.out.println("before hello world  called");
	}
	
	private void method2() {
		System.out.println("after hello world  called");
	}
	
}
