package cts.aop;

public class MainCode {

	public void display() {

		System.out.println("hello world");
	}
}
